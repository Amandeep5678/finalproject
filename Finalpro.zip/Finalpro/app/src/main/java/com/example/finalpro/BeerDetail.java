package com.example.finalpro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class BeerDetail extends AppCompatActivity {
    ImageView imgvb;
    TextView textVName,textVtag,textVabv,textVph,textVibu,textVdescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beer_detail);
        textVabv= findViewById(R.id.txtabv);
        textVdescription=findViewById(R.id.txdescription);
        textVName= findViewById(R.id.txtBname);
        textVibu= findViewById(R.id.txtibu);
        textVtag=findViewById(R.id.txtTag);
        textVph=findViewById(R.id.txtph);
        imgvb=findViewById(R.id.img_bdetail);
        Intent i  = getIntent();
        Beer b =i.getParcelableExtra("beers");
        Picasso.get().load(b.getImage_url()).into(imgvb);
        textVName.setText("Name"+b.getName());
        textVph.setText("ph" +String.valueOf(b.getPh()));
        textVtag.setText("tagline"+b.getTagline());
        textVibu.setText("ibu" +String.valueOf(b.getIbu()));
        textVdescription.setText("Description"+b.getDescription());
        textVdescription.setMovementMethod(new ScrollingMovementMethod());
        textVabv.setText("abv" +String.valueOf(b.getAbv()));


    }
}