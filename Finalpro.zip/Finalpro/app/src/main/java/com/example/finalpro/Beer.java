package com.example.finalpro;

import android.os.Parcel;
import android.os.Parcelable;

public class Beer implements Parcelable {


    private String name;
    private String image_url;
    private Double abv;
    private Double ph;
    private int ibu;
    public String tagline;
    private String description;
    public Beer(String name, String image_url, Double abv, int ibu, Double ph, String tagline, String description) {
        this.name = name;
        this.image_url = image_url;
        this.abv = abv;
        this.ph = ph;
        this.ibu = ibu;
        this.tagline = tagline;
        this.description = description;

    }

    protected Beer(Parcel in) {
        name = in.readString();
        image_url = in.readString();
        ibu = in.readInt();
        tagline = in.readString();
        description = in.readString();
        ph = in.readDouble();
        abv = in.readDouble();


    }

    public static final Creator<Beer> CREATOR = new Creator<Beer>() {
        @Override
        public Beer createFromParcel(Parcel in) {
            return new Beer(in);
        }

        @Override
        public Beer[] newArray(int size) {
            return new Beer[size];
        }
    };



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public Double getAbv() {
        return abv;
    }

    public void setAbv(Double abv) {
        this.abv = abv;
    }

    public Double getPh() {
        return ph;
    }

    public void setPh(Double ph) {
        this.ph = ph;
    }

    public int getIbu() {
        return ibu;
    }

    public void setIbu(int ibu) {
        this.ibu = ibu;
    }

    public String getTagline() {
        return tagline;
    }

    public void setTagline(String tagline) {
        this.tagline = tagline;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(image_url);
        dest.writeInt(ibu);
        dest.writeDouble(abv);
        dest.writeDouble(ph);
        dest.writeString(tagline);
        dest.writeString(description);
    }
}


