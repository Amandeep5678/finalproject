package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.Transliterator;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    ListView lisv;
    ListAdapter listAdapter;
    ArrayList<Beer> bArraylist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lisv = findViewById(R.id.ListView);
        bArraylist= new ArrayList<Beer>();

        String beerurl = getResources().getString(R.string.beerurl);
        bArraylist= getData(beerurl);
        listAdapter = new ListAdapter(MainActivity.this, getData(beerurl));

        lisv.setAdapter(listAdapter);
        lisv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), bArraylist.get(position).getName(), Toast.LENGTH_LONG).show();
                Intent i = new Intent(MainActivity.this, BeerDetail.class);
               i.putExtra("beer",bArraylist.get(position));
               startActivity(i);
            }
        });

    }
    public ArrayList<Beer> getData(String url){
        ArrayList<Beer> beerArrayList= new ArrayList<>();
        try {
            String jsondata = new  Async().execute(url).get();
            JSONObject mainobj = new JSONObject(jsondata);
            JSONArray beerArray = mainobj.getJSONArray("Beer");

            for(int i=0; i<beerArray.length();i++){
                JSONObject childobj = beerArray.getJSONObject(i);
                String name =childobj.getString("name");
                String image = childobj.getString("image_url") ;
                 String abv=childobj.getString("abv");
                 String ph= childobj.getString("ph") ;
                 String ibu=childobj.getString("ibu");
                String tag =childobj.getString("tagline");
                String description=childobj.getString("description");
                beerArrayList.add (new Beer(name,image,abv,ph,ibu,description,tag));
            }
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }
        catch (ExecutionException e){
            e.printStackTrace();
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        System.out.println("Size of arraylist(Outside try):"+beerArrayList.size());
        return  beerArrayList;
    }
}