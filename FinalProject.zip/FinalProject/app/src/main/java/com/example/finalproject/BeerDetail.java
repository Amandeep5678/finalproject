package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class BeerDetail extends AppCompatActivity {
    ImageView imgvb;
    TextView textVName,textVtag,textVabv,textVph,textVibu,textVdescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beer_detail);
        textVabv= findViewById(R.id.txtabv);
        textVdescription=findViewById(R.id.txdescription);
        textVName= findViewById(R.id.txtBname);
        textVibu= findViewById(R.id.txtibu);
        textVtag=findViewById(R.id.txtTag);
        textVph=findViewById(R.id.txtph);
        imgvb=findViewById(R.id.img_bdetail);
        Intent i  = getIntent();
        Beer b =i.getParcelableExtra("Beer");
        Picasso.get().load(b.getImage()).into(imgvb);
        textVName.setText(b.getName());
        textVph.setText(b.getPh());
        textVtag.setText(b.getTag());
        textVibu.setText(b.getIbu());
        textVdescription.setText(b.getDescription());
        textVabv.setText(b.getAbv());


    }
}