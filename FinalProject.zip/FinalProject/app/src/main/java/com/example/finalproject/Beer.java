package com.example.finalproject;

import android.os.Parcel;
import android.os.Parcelable;

public class Beer  implements Parcelable{


    private String name;
    private String image_url;
    private String abv;
    private String ph ;
    private String ibu;
    public String tagline;
    private String description;



    public Beer(String abv, String ph, String ibu, String description, String name, String image_url, String tagline) {
        this.abv = abv;
        this.ph = ph;
        this.ibu = ibu;
        this.description = description;
        this.tagline=tagline;
        this.name= name;
        this.image_url = image_url;
    }
  protected Beer(Parcel in){
        name= in .readString();
        image_url= in.readString();
        description=in.readString();
        abv=in.readString();
        tagline=in.readString();
        ph=in.readString();
        ibu=in.readString();

  }
  public static final Parcelable.Creator<Beer> CREATOR=new Creator<Beer>() {
      @Override
      public Beer createFromParcel(Parcel in) {
          return new Beer(in);
      }

      @Override
      public Beer[] newArray(int size) {
          return new Beer[size];
      }
  };
    public String getName() {
        return name;
    }

    public void setName(String Name) {
        this.name = name;
    }

    public String getImage() {
        return image_url;
    }

    public void setImage(String image) {
        this.image_url = image_url;
    }

    public String getAbv() {
        return abv;
    }

    public void setAbv(String abv) {
        this.abv = abv;
    }
    public String getTag() {
        return tagline;
    }

    public void setTag(String tag) {
        this.tagline = tagline;
    }

    public String getPh() {
        return ph;
    }

    public void setPh(String ph) {
        this.ph = ph;
    }

    public String getIbu() {
        return ibu;
    }

    public void setIbu(String ibu) {
        this.ibu = ibu;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

  public int describeContents(){
        return 0;
  }

 public void writeToParcel(Parcel dest,int flags){
        dest.writeString(name);
     dest.writeString(image_url);
     dest.writeString(ibu);
     dest.writeString(ph);
     dest.writeString(abv);
     dest.writeString(tagline);
     dest.writeString(description);
 }


}
